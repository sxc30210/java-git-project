package com.easylearnjava.csvtodb;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;


public class MainClass {
	
//Variable Declaration
	static String inputFile = "C:\\Users\\Administrator\\Desktop\\CodeChallenge\\InputFile\\Data.csv";
	 static String url = "jdbc:sqlite:C:\\Users\\Administrator\\Desktop\\CodeChallenge\\Database\\Test1.db";
	static int totalRecord = 0;
    static int failedRecord= 0;
    //main method
	public static void main(String[] args) throws IOException {
		//declaring bad file name with timestamp
		 String time = new SimpleDateFormat("yyyyMMddHHmm'.txt'").format(new Date());
		 String fileName = "C:\\Users\\Administrator\\Desktop\\CodeChallenge\\Badfile\\bad-data" + time + ".csv";
		
		 try {
			// setting up database connection
			Class.forName("org.sqlite.JDBC");
			System.out.println("Load Drivers Success");

			Connection connection = DriverManager.getConnection(url);
			//
			// Delete previous records before each run
			//
			String query1 = "DELETE from X";
			PreparedStatement preparedStatement1 = connection.prepareStatement(query1);
			preparedStatement1.executeUpdate();
			//
			// Insert Query
			//
			String query = "INSERT INTO X VALUES(?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement preparedStatement = connection.prepareStatement(query);

			// Reading the data from CSV file
			FileInputStream fis = null;
			InputStreamReader isr = null;
			BufferedReader bReader = null;
			fis = new FileInputStream(inputFile);
			isr = new InputStreamReader(fis);
			bReader = new BufferedReader(isr);
			// Declaring string and Array variable
			String line = null;
			String[] stringX = new String[12];
			// functionality to check the number of records
	
			while (true) {
				line = bReader.readLine();
				// check line get empty, exit loop
				if (line == null) {
					break;
				} else {
					// checking else condition
					stringX = null;
					// checking if condition inside outer else
					stringX = line.split(",");
					//counting total records
					totalRecord++;
					//checking if for column records
					if (stringX.length == 11) {
						//executing SQL query
						preparedStatement.setString(1, stringX[0]);
						preparedStatement.setString(2, stringX[1]);
						preparedStatement.setString(3, stringX[2]);
						preparedStatement.setString(4, stringX[3]);
						preparedStatement.setString(5, "\"" + stringX[4] + "," + stringX[5] + "\"");
						preparedStatement.setString(6, stringX[6]);
						preparedStatement.setString(7, stringX[7]);
						preparedStatement.setString(8, stringX[8]);
						preparedStatement.setString(9, stringX[9]);
						preparedStatement.setString(10, stringX[10]);
	
						preparedStatement.executeUpdate();
						
					} else 
					{

						try {
							//writing bad records into above decalared badfile
							FileWriter writer = new FileWriter(fileName, true);
							BufferedWriter bw = new BufferedWriter(writer);
							PrintWriter pw = new PrintWriter(bw);
							pw.println(line);
						    System.out.println(line);
							pw.flush();
							pw.close();
							//counting total failed records
							failedRecord++;		
						} 
						catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
			}	
				
		} 
		catch (Exception e) {

			e.printStackTrace();
		}//calling  logfile method
		logfile();
	}// end main

	public static void logfile() throws IOException {
     // logging records into log file
		FileHandler fh = new FileHandler("C:\\Users\\Administrator\\Desktop\\CodeChallenge\\Logs\\mylog.log");
		Logger logger = Logger.getLogger("MyLog");
		logger.addHandler(fh);
		fh.setFormatter(new SimpleFormatter());
		logger.info("The number of failed records in the file " + failedRecord);
		logger.info("The number of records Received " + totalRecord);
		logger.info("The number of Records Successful saved in database " + (totalRecord - failedRecord));

	}

}// end class